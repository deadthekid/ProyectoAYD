package edu.unah.ad;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AutomotrizApplicationTests {

	@Test
	void contextLoads() {
	}

}
